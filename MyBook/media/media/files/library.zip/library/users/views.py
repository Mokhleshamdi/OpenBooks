from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import Group, User
from django.urls import reverse
from .forms import UserUpdateForm
from books.forms import BookForm
from books.models import Book
# Create your views here.

def register(request):
    form = UserCreationForm(request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            instance = form.save()
            grp = Group.objects.get(name='members')
            instance.groups.add(grp)
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('/')

    context = {'form': form}
    return render(request, 'registration/register.html', context)


def member_add(request):
    form = UserCreationForm(request.POST or None)

    if request.method == 'POST':
        if form.is_valid():
            instance = form.save()
            grp = Group.objects.get(name='members')
            instance.group.add(grp)
            return redirect('/')
    context = {'form': form}
    return render(request, 'member_add.html', context)

def member_list(request):
    members = User.objects.filter(groups__name='members')
    context = {'members': members}
    return render(request, 'users/member_list.html', context)

def member_detail(request, id):
    member = User.objects.get(id=id)
    form = UserUpdateForm(request.POST or None)
    if request.method == 'POST':
        if form.is_valid():
            member.username = form.cleaned_data.get('username')
            member.first_name = form.cleaned_data.get('first_name')
            member.last_name = form.cleaned_data.get('last_name')
            member.email = form.cleaned_data.get('email')
            member.save()
            return redirect(reverse('member_detail', kwargs={'id':id}))
    context = {'member': member, 'form': form}
    return render(request, 'users/member_detail.html', context)

def member_delete(request, id):
    member = User.objects.get(id=id)
    member.delete()
    return redirect(reverse('member_list'))


def book_add(request):
    form = BookForm(request.POST or None, request.FILES or None)

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            return redirect(reverse('book_list'))
    context = {'form': form}
    return render(request, 'users/book_add.html', context)


def member_search(request):
    query = request.GET.get('q')
    members = User.objects.filter(username=query)
    context = {'members': members}
    return render(request, 'users/member_search.html', context)

def book_delete(request, id):
    book = Book.objects.get(id=id)
    book.delete()
    return redirect('/')


def book_update(request, id):
    form = BookForm(request.POST or None, request.FILES or None)
    book = Book.objects.get(id=id)
    if request.method == 'POST':
        if form.is_valid():
            book = form
            book.save()
            return redirect(reverse('book_detail', kwargs={'id':id}))

    context = {'form': form}
    return render(request, 'books/book_update.html', context)