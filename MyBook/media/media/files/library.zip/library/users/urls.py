from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView

from . import views

urlpatterns = [
    path('register', views.register, name='register'),
    path('login', LoginView.as_view(), name='login'),
    path('logout', LogoutView.as_view(), name='logout'),
    path('members', views.member_list, name='member_list'),
    path('members/<int:id>', views.member_detail, name='member_detail'),
    path('members/delete/<int:id>', views.member_delete, name='member_delete'),
    path('book_add', views.book_add, name='book_add'),
    path('book_delete/<int:id>', views.book_delete, name='book_delete'),
    path('book_update/<int:id>', views.book_update, name='book_update'),
    path('member_search', views.member_search, name='member_search'),
]