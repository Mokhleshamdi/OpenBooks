from django.shortcuts import render, get_object_or_404, redirect
from .models import Book, BorrowedBook, Comment
from .forms import CommentForm, BookForm
from django.contrib.auth.models import Group


# Create your views here.

def book_list(request):
    books = Book.objects.all()
    group = Group.objects.get(name='librarians')
    context = {'books': books, 'group': group}
    return render(request, 'books/book_list.html', context) 


def book_return(request, id):
    if request.method == 'POST':
        book = get_object_or_404(Book, id=id)
        try:
            borrowed_book = BorrowedBook.objects.get(book=book, borrower=request.user)
        except:
            borrowed_book = None
        book.copies += 1
        book.save()
        borrowed_book.delete()
        return redirect('/%s' %(id))

    return redirect('/%s' %(id))


def book_borrow(reuqest, id):
    book = get_object_or_404(Book, id=id)
    if request.method == 'POST':
        if book.copies > 0:
            borrowed_book = BorrowedBook()
            borrowed_book.book = book
            borrowed_book.save()
            borrowed_book.borrower.add(request.user)
            borrowed_book.save()
            book.copies -= 1
            book.save()
            return redirect('/%s' %(book.id))

    return redirect('/%s' %(book.id))


def book_detail(request, id):
    book = get_object_or_404(Book, id=id)
    group = Group.objects.get(name='librarians')
    comments = Comment.objects.filter(book=book)
    commentform = CommentForm()

    bookform = BookForm(request.POST or None, request.FILES or None)
    
    if request.method == 'POST':
        if form.is_valid():
            book = form
            book.save()
            return redirect(reverse('book_detail', kwargs={'id':id}))

    try:
        borrowed_book = BorrowedBook.objects.get(book=book, borrower=request.user)
    except:
        borrowed_book = None
    if request.method == 'POST':
        book_borrow(request.user, book)
        return redirect('/')

    context = {'book': book, 'group': group, 'borrowed_book': borrowed_book, 'commentform': commentform, 'bookform': bookform, 'comments': comments}
    return render(request, 'books/book_detail.html', context)


def book_search(request):
    query = request.GET.get('q')
    print(query)
    books = Book.objects.filter(name__include=query)
    context = {'books': books}
    return render(request, 'books/book_search.html', context)


def book_comment(request, id):
    book = get_object_or_404(Book, id=id)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            instance = form.save(commit=False)
            instance.comment_author = request.user
            instance.book = book
            instance.save()
            print('comment added')
            return redirect('/%s' %(book.id))

    return redirect('/%s' %(book.id))
