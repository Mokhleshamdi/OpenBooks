from django import forms
from .models import Comment, Book

class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        fields = ['content']


class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'