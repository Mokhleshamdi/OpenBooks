from django.urls import path
from . import views

urlpatterns = [
    path('', views.book_list, name='book_list'),
    path('<int:id>', views.book_detail, name='book_detail'),
    path('borrow/<int:id>', views.book_borrow, name='book_borrow'),
    path('return/<int:id>', views.book_return, name='book_return'),
    path('comment/<int:id>', views.book_comment, name='book_comment'),
    path('search', views.book_search, name='book_search'),
]